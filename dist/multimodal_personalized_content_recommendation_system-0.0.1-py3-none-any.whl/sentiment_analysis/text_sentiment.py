from transformers import pipeline

# Add your text sentiment analysis code here
