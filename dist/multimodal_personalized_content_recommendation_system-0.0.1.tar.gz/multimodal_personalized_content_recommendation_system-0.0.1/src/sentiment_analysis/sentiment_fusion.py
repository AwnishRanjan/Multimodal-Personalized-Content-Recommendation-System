# Add code for fusing text and image sentiment
